package idCreation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.commons.io.IOUtils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

/**
 * Servlet implementation class idCardPage
 */
public class idCardPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public idCardPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String query="SELECT * FROM iddetails";		
		try {
			PreparedStatement ps=myCon.getConnection().prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				String y=rs.getString(2);
				String ur="";
				for(int i=0;i<y.length();i++) {
					ur+=y.charAt(i)+" ";
				}
				ur=ur.trim();
				
				String imagePath1 = "C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+rs.getString(17); // Replace with your local image path
		        File imageFile1 = new File(imagePath1);
		        if (!imageFile1.exists()) {
		            response.sendError(HttpServletResponse.SC_NOT_FOUND);
		            return;
		        }
		        FileInputStream fis1 = new FileInputStream(imageFile1);
		        byte[] imageData1 = IOUtils.toByteArray(fis1);
		        fis1.close();
		        String base64Image1 = java.util.Base64.getEncoder().encodeToString(imageData1);
		        String imageSrc1 = "data:image/jpg;base64," + base64Image1;
		        
		        String imagePath2 = "C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+rs.getString(18); // Replace with your local image path
		        File imageFile2 = new File(imagePath2);
		        if (!imageFile2.exists()) {
		            response.sendError(HttpServletResponse.SC_NOT_FOUND);
		            return;
		        }
		        FileInputStream fis2 = new FileInputStream(imageFile2);
		        byte[] imageData2 = IOUtils.toByteArray(fis2);
		        fis2.close();
		        String base64Image2 = java.util.Base64.getEncoder().encodeToString(imageData2);
		        String imageSrc2 = "data:image/jpg;base64," + base64Image2;
		        
		        String imagePath = "C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+rs.getString(19); // Replace with your local image path
		        File imageFile = new File(imagePath);
		        if (!imageFile.exists()) {
		            response.sendError(HttpServletResponse.SC_NOT_FOUND);
		            return;
		        }
		        FileInputStream fis = new FileInputStream(imageFile);
		        byte[] imageData = IOUtils.toByteArray(fis);
		        fis.close();
		        String base64Image = java.util.Base64.getEncoder().encodeToString(imageData);
		        String imageSrc = "data:image/jpg;base64," + base64Image;
				
		        
		        String imagePath3 = "C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+rs.getString(1)+".jpg"; // Replace with your local image path
		        File imageFile3 = new File(imagePath3);
		        if (!imageFile3.exists()) {
		            response.sendError(HttpServletResponse.SC_NOT_FOUND);
		            return;
		        }
		        FileInputStream fis3 = new FileInputStream(imageFile3);
		        byte[] imageData3 = IOUtils.toByteArray(fis3);
		        fis3.close();
		        String base64Image3 = java.util.Base64.getEncoder().encodeToString(imageData3);
		        String imageSrc3 = "data:image/jpg;base64," + base64Image3;
		        
				RequestDispatcher rd=request.getRequestDispatcher("idSelection.html");
				rd.include(request, response);
				out.print("<div id=\"id01\" class=\"modal1\">\r\n"
						+ "  \r\n"
						+ "  <form class=\"modal-content1 animate1\" action=\"\" method=\"post\">\r\n"
						+ "    <div class=\"imgcontainer1\">\r\n"
						+ "      <span onclick=\"document.getElementById('id01').style.display='none'\" class=\"close1\" title=\"Close Modal\"></span>\r\n"
						+ "    </div>\r\n"
						+ "\r\n"
						+ "<div class=\"id_card\">\r\n"
						+ "<h1>ID Card Generate</h1>\r\n"
						+ "<div class=\"create_idCard\">\r\n"
						+ "<table class=\"front_id\">\r\n"
						+ "<tr>\r\n"
						+ "<td rowspan=\"11\" id=\"id1\">"+ur+"</td>\r\n"
						+ "<td colspan=\"3\"><img src=\""+imageSrc+"\" class=\"logoimg\"/></td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\" class=\"cname\">"+rs.getString(8)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\" class=\"caddress\">"+rs.getString(13)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td>"+rs.getString(11)+"</td>\r\n"
						+ "<td><img src=\""+imageSrc1+"\" class=\"yourimg\"/></td>\r\n"
						+ "<td>"+rs.getString(12)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\">"+rs.getString(3)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\">"+rs.getString(5)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\">"+rs.getString(9)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\">"+rs.getString(10)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\"><img src=\""+imageSrc2+"\" class=\"signimg\"/></td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"3\">Signature</td>\r\n"
						+ "</tr>\r\n"
						+ "</table>\r\n"
						+ "\r\n"
						+ "\r\n"
						+ "<table class=\"back_id\">\r\n"
						+ "<tr>\r\n"
						+ "<td class=\"cbold\">Date</td>\r\n"
						+ "<td>"+rs.getString(6)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td class=\"cbold\">Blood</td>\r\n"
						+ "<td>"+rs.getString(7)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td class=\"cbold\">Father Name</td>\r\n"
						+ "<td>"+rs.getString(4)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td class=\"cbold\">Address</td>\r\n"
						+ "<td>"+rs.getString(14)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"2\"><img src=\""+imageSrc3+"\" class=\"qrimg\"/></td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td class=\"cbold\">Pin Code</td>\r\n"
						+ "<td>"+rs.getString(15)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td class=\"cbold\">Phone Number</td>\r\n"
						+ "<td>"+rs.getString(16)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "</table>\r\n"
						+ "</div>\r\n"
						+ "<a href=\"idSelection.html\">Cancel</a>\r\n"
						+ "<a href=\"home.html\">Save</a>\r\n"
						+ "</div>\r\n"
						+ "  </form>\r\n"
						+ "</div>");
			}
		} catch(Exception e) {
			out.print(e);
		}
	}

}

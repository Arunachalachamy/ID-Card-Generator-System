package idCreation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class loginPage
 */
public class loginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String query="SELECT * FROM register WHERE (email=? OR pnum=?) AND pwd=?";
		try {
			PreparedStatement ps=myCon.getConnection().prepareStatement(query);
			ps.setString(1, request.getParameter("uname"));
			ps.setString(2, request.getParameter("uname"));
			ps.setString(3, request.getParameter("pwd"));
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				String name=rs.getString(2);
				RequestDispatcher rd=request.getRequestDispatcher("home.html");
				rd.include(request, response);
				out.print("<html>\r\n"
						+ "<head>\r\n"
						+ "<style>\r\n"
						+ ".main {\r\n"
						+ "  display:block;\r\n"
						+ "}\r\n"
						+ "#id01 {\r\n"
						+ "  display:none;\r\n"
						+ "}\r\n"
						+ "#id02 {\r\n"
						+ "  display:none;\r\n"
						+ "}\r\n"
						+ ".topnav-right2 {\r\n"
						+ "  float: right;\r\n"
						+ "}"
						+ ".topnav-right1 {\r\n"
						+ "  display:none;\r\n"
						+ "}"
						+ "</style>\r\n"
						+ "</head>\r\n"
						+ "<body>\r\n"
						+ "<div class=\"navbar1\">\r\n"
						+ "<div class=\"heading\">\r\n"
						+ "<h1>ID Card</h1>\r\n"
						+ "</div>\r\n"
						+ "<div class=\"topnav1\">\r\n"
						+ "  <a href=\"#home\" onclick=\"document.getElementById('generate').style.display='none';document.getElementById('home').style.display='block';\">Home</a>\r\n"
						+ "<div class=\"dropdown1\">\r\n"
						+ "  <button class=\"dropbtn1\" onclick=\"myFunction()\">Generate\r\n"
						+ "    <i class=\"fa fa-caret-down\"></i>\r\n"
						+ "  </button>\r\n"
						+ "  <div class=\"dropdown-content1\" id=\"myDropdown\">\r\n"
						+ "    <a href=\"#idcard\" onclick=\"document.getElementById('home').style.display='none';document.getElementById('generate').style.display='block';\">ID Card</a>\r\n"
						+ "    <a href=\"#visitingcard\" onclick=\"document.getElementById('home').style.display='none';document.getElementById('generate').style.display='block';\">Visiting Card</a>\r\n"
						+ "  </div>\r\n"
						+ "  </div> \r\n"
						+ "  <a href=\"#view\" onclick=\"document.getElementById('home').style.display='none';document.getElementById('view').style.display='block';\">View</a>\r\n"
						+ "  <a href=\"#about\" onclick=\"document.getElementById('generate').style.display='none';document.getElementById('home').style.display='block'\">About</a>\r\n"
						+ "  <a href=\"#contact\"onclick=\"document.getElementById('generate').style.display='none';document.getElementById('home').style.display='block'\">Contact</a>\r\n"
						+ "  <div class=\"topnav-right2\">\r\n"
						+ "<div class=\"dropdown1\">\r\n"
						+ "  <button class=\"dropbtn2\" onclick=\"myFun()\">"+name+"\r\n"
						+ "    <i class=\"fa fa-caret-down\"></i>\r\n"
						+ "  </button>\r\n"
						+ "  <div class=\"dropdown-content1\" id=\"myDropdown1\">\r\n"
						+ "    <a href=\"home.html\" onclick=\"lschange()\">Sign out</a>\r\n"
						+ "  </div>\r\n"
						+ "  </div> "
						+ "  </div>\r\n"
						+ "</div>\r\n"
						+ "</div>"
						+ "<script type=\"text/javascript\">\r\n"
						+ "localStorage.setItem('num',1);\r\n"
						+ "</script>"
						+ "</body>\r\n"
						+ "</html>");
			}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("home.html");
				rd.include(request, response);
				out.print("<html>\r\n"
						+ "<head>\r\n"
						+ "<style>\r\n"
						+ ".alert3 {\r\n"
						+ "  display: block;\r\n"
						+ "}\r\n"
						+ ".main {\r\n"
						+ "  display:block;\r\n"
						+ "}\r\n"
						+ "#id01 {\r\n"
						+ "  display:block;\r\n"
						+ "}\r\n"
						+ "#id02 {\r\n"
						+ "  display:none;\r\n"
						+ "}\r\n"
						+ "</style>\r\n"
						+ "</head>\r\n"
						+ "<body>\r\n"
						+ "</body>\r\n"
						+ "</html>");
			}
		} catch(Exception e) {
			out.print(e);
		}
	}

}

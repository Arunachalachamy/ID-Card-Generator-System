package idCreation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class registerPage
 */
public class registerPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registerPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String query="INSERT INTO register(fname,lname,gender,email,pnum,pwd,address) VALUES (?,?,?,?,?,?,?)";
		try {
			if(request.getParameter("rpwd").equals(request.getParameter("rcpwd"))) {
				PreparedStatement ps=myCon.getConnection().prepareStatement(query);
				ps.setString(1, request.getParameter("rfname"));
				ps.setString(2, request.getParameter("rlname"));
				ps.setString(3, request.getParameter("rgender"));
				ps.setString(4, request.getParameter("remail"));
				ps.setString(5, request.getParameter("rpnum"));
				ps.setString(6, request.getParameter("rpwd"));
				ps.setString(7, request.getParameter("raddress"));
				if(ps.executeUpdate()>0) {
					RequestDispatcher rd=request.getRequestDispatcher("home.html");
					rd.include(request, response);
					out.print("<html>\r\n"
							+ "<head>\r\n"
							+ "<style>\r\n"
							+ ".alert2 {\r\n"
							+ "  display: block;\r\n"
							+ "}\r\n"
							+ ".main {\r\n"
							+ "  display:block;\r\n"
							+ "}\r\n"
							+ "#id01 {\r\n"
							+ "  display:none;\r\n"
							+ "}\r\n"
							+ "#id02 {\r\n"
							+ "  display:block;\r\n"
							+ "}\r\n"
							+ "</style>\r\n"
							+ "</head>\r\n"
							+ "<body>\r\n"
							+ "</body>\r\n"
							+ "</html>");
				}
			}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("home.html");
				rd.include(request, response);
				out.print("<html>\r\n"
						+ "<head>\r\n"
						+ "<style>\r\n"
						+ ".alert1 {\r\n"
						+ "  display: block;\r\n"
						+ "}\r\n"
						+ ".main {\r\n"
						+ "  display:block;\r\n"
						+ "}\r\n"
						+ "#id01 {\r\n"
						+ "  display:none;\r\n"
						+ "}\r\n"
						+ "#id02 {\r\n"
						+ "  display:block;\r\n"
						+ "}\r\n"
						+ "</style>\r\n"
						+ "</head>\r\n"
						+ "<body>\r\n"
						+ "</body>\r\n"
						+ "</html>");
			}
		}catch(Exception e) {
			out.print(e);
		}
	}

}

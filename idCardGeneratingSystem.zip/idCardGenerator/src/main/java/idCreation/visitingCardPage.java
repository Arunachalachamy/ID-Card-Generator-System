package idCreation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.commons.io.IOUtils;

/**
 * Servlet implementation class visitingCardPage
 */
public class visitingCardPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public visitingCardPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String query="SELECT * FROM vcdetails";
		try {
			PreparedStatement ps=myCon.getConnection().prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				String imagePath = "C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+rs.getString(11); // Replace with your local image path
		        File imageFile = new File(imagePath);
		        if (!imageFile.exists()) {
		            response.sendError(HttpServletResponse.SC_NOT_FOUND);
		            return;
		        }
		        FileInputStream fis = new FileInputStream(imageFile);
		        byte[] imageData = IOUtils.toByteArray(fis);
		        fis.close();
		        String base64Image = java.util.Base64.getEncoder().encodeToString(imageData);
		        String imageSrc = "data:image/jpg;base64," + base64Image;
		        
				RequestDispatcher rd=request.getRequestDispatcher("visitingCardSelection.html");
				rd.include(request, response);
				out.print("<div id=\"id01\" class=\"modal1\">\r\n"
						+ "  \r\n"
						+ "  <form class=\"modal-content1 animate1\" action=\"loginPage\" method=\"post\">\r\n"
						+ "    <div class=\"imgcontainer1\">\r\n"
						+ "      <span onclick=\"document.getElementById('id01').style.display='none'\" class=\"close1\" title=\"Close Modal\"></span>\r\n"
						+ "    </div>\r\n"
						+ "\r\n"
						+ "<div class=\"id_card\">\r\n"
						+ "<h1>Visiting Card Generate</h1>\r\n"
						+ "<div class=\"create_idCard\">\r\n"
						+ "<table class=\"front_id\">\r\n"
						+ "<tr>\r\n"
						+ "<td><img src=\""+imageSrc+"\" class=\"clogoimg\"/><br>\r\n"
						+ "<span>"+rs.getString(3)+"</span><br>\r\n"
						+ ""+rs.getString(4)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "</table>\r\n"
						+ "\r\n"
						+ "\r\n"
						+ "<table class=\"back_id\">\r\n"
						+ "<tr>\r\n"
						+ "<td rowspan=\"5\"><img src=\""+imageSrc+"\" class=\"clogoimg\"/><br><span>"+rs.getString(3)+"</span><br>"+rs.getString(4)+"</td>\r\n"
						+ "<td><span>"+rs.getString(5)+"</span></td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td>"+rs.getString(6)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td style=\"text-align:left;\"><img src=\"https://cdn-icons-png.flaticon.com/128/1040/1040243.png\" class=\"icon\"/> "+rs.getString(7)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td style=\"text-align:left;\"><img src=\"https://cdn-icons-png.flaticon.com/128/4213/4213179.png\" class=\"icon\"/> "+rs.getString(8)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td style=\"text-align:left;\"><img src=\"https://cdn-icons-png.flaticon.com/128/732/732200.png\" class=\"icon\"/> "+rs.getString(2)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "<tr>\r\n"
						+ "<td colspan=\"2\" style=\"background-color:rgba(255,215,0,0.5)\">"+rs.getString(9)+rs.getString(10)+"</td>\r\n"
						+ "</tr>\r\n"
						+ "</table>\r\n"
						+ "\r\n"
						+ "</div>\r\n"
						+ "<a href=\"visitingCardSelection.html\">Cancel</a>\r\n"
						+ "<a href=\"home.html\">Save</a>\r\n"
						+ "</div>\r\n"
						+ "  </form>\r\n"
						+ "</div>");
			}
		} catch(Exception e) {
			out.print(e);
		}
	}

}

package idCreation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.PreparedStatement;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

/**
 * Servlet implementation class idDetailsPage
 */
@MultipartConfig
public class idDetailsPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public idDetailsPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		String query="INSERT INTO iddetails(fid,uor,name,fname,rnum,bod,bgroup,cname,dept,branch,syear,eyear,caddress,address,pcode,cnum,yphoto,ysign,clogo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PrintWriter out=response.getWriter();
		try {
			PreparedStatement ps=myCon.getConnection().prepareStatement(query);
			ps.setString(1, request.getParameter("fid"));
			ps.setString(2, request.getParameter("ur"));
			ps.setString(3, request.getParameter("name"));
			ps.setString(4, request.getParameter("fname"));
			ps.setString(5, request.getParameter("rnum"));
			ps.setString(6, request.getParameter("dob"));
			ps.setString(7, request.getParameter("bgroup"));
			ps.setString(8, request.getParameter("cname"));
			ps.setString(9, request.getParameter("dept"));
			ps.setString(10, request.getParameter("branch"));
			ps.setString(11, request.getParameter("syear"));
			ps.setString(12, request.getParameter("eyear"));
			ps.setString(13, request.getParameter("caddress"));
			ps.setString(14, request.getParameter("address"));
			ps.setString(15, request.getParameter("pcode"));
			ps.setString(16, request.getParameter("cnum"));
			
			Part file1=request.getPart("yphoto");
			String imageFileName1=file1.getSubmittedFileName();
			String uploadPath1="C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+imageFileName1;
			FileOutputStream fos1=new FileOutputStream(uploadPath1);
			InputStream is1=file1.getInputStream();
			byte data1[]=new byte[is1.available()];
			is1.read(data1);
			fos1.write(data1);
			fos1.close();
			
			Part file2=request.getPart("ysign");
			String imageFileName2=file2.getSubmittedFileName();
			String uploadPath2="C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+imageFileName2;
			FileOutputStream fos2=new FileOutputStream(uploadPath2);
			InputStream is2=file2.getInputStream();
			byte data2[]=new byte[is2.available()];
			is2.read(data2);
			fos2.write(data2);
			fos2.close();
			
			Part file=request.getPart("clogo");
			String imageFileName=file.getSubmittedFileName();
			String uploadPath="C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+imageFileName;
			FileOutputStream fos=new FileOutputStream(uploadPath);
			InputStream is=file.getInputStream();
			byte data[]=new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
			
			String data11 = "Name: "+request.getParameter("name")+"\n"+"Roll number: "+request.getParameter("rnum");
	        String filename = request.getParameter("fid"); // Specify the practical path where you want to store the QR code imag

	        File f=new File("C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+filename+".jpg");

	        try {
	            BitMatrix m = new MultiFormatWriter().encode(data11, BarcodeFormat.QR_CODE, 500, 500);
	            MatrixToImageWriter.writeToPath(m, "jpg", Paths.get(f.toURI()));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
			
			ps.setString(17, imageFileName1);
			ps.setString(18, imageFileName2);
			ps.setString(19, imageFileName);
			if(ps.executeUpdate()>0) {
				RequestDispatcher rd=request.getRequestDispatcher("idSelection.html");
				rd.forward(request, response);
			}
		} catch(Exception e) {
			System.out.println(e);
		}
	}

}

package idCreation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class vcDetailsPage
 */
@MultipartConfig
public class vcDetailsPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public vcDetailsPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String query="INSERT INTO vcdetails(fid,email,cname,ctype,name,role,cwebsite,cnum,caddress,pcode,clogo) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=myCon.getConnection().prepareStatement(query);
			ps.setString(1, request.getParameter("fid"));
			ps.setString(2, request.getParameter("email"));
			ps.setString(3, request.getParameter("cname"));
			ps.setString(4, request.getParameter("ctype"));
			ps.setString(5, request.getParameter("name"));
			ps.setString(6, request.getParameter("role"));
			ps.setString(7, request.getParameter("cwebsite"));
			ps.setString(8, request.getParameter("cnum"));
			ps.setString(9, request.getParameter("caddress"));
			ps.setString(10, request.getParameter("pcode"));
			
			Part file=request.getPart("clogo");
			String imageFileName=file.getSubmittedFileName();
			String uploadPath="C:\\Users\\AruNa\\eclipse-workspace\\idCardGenerator\\images\\"+imageFileName;
			FileOutputStream fos=new FileOutputStream(uploadPath);
			InputStream is=file.getInputStream();
			byte data[]=new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
			
			ps.setString(11, imageFileName);
			if(ps.executeUpdate()>0) {
				RequestDispatcher rd=request.getRequestDispatcher("visitingCardSelection.html");
				rd.forward(request, response);
			}
		} catch(Exception e) {
			System.out.println(e);
		}
	}

}
